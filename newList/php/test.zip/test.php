<?php
error_reporting(0);

$list = 0;
$listId = 0;
$rankid = 88;
$key = 'link';
$hash = 0;
$id = 0;
$test = 88;
$pageSize = 6;
$spit = array();
$spit = explode("&",$_SERVER["QUERY_STRING"]);
for($i=0;$i<count($spit);$i++){
	if(explode("=",$spit[$i])[0] == 'list'){
		$list = explode("=",$spit[$i])[1];
	}
	if(explode("=",$spit[$i])[0] == 'listId'){
		$listId = explode("=",$spit[$i])[1];
	}
	if(explode("=",$spit[$i])[0] == 'rankid'){
		$rankid = explode("=",$spit[$i])[1];
	}
	if(explode("=",$spit[$i])[0] == 'key'){
		$key = explode("=",$spit[$i])[1];
	}
	if(explode("=",$spit[$i])[0] == 'hash'){
		$hash = explode("=",$spit[$i])[1];
	}
	if(explode("=",$spit[$i])[0] == 'id'){
		$id = explode("=",$spit[$i])[1];
	}
	if(explode("=",$spit[$i])[0] == 'test'){
		$test = explode("=",$spit[$i])[1];
	}
	if(explode("=",$spit[$i])[0] == 'pageSize'){
		$pageSize = explode("=",$spit[$i])[1];
	}
}
// api -> http://m.kugou.com
// search -> http://www.kugou.com/
// title -> http://mobilecdn.kugou.com/api/v3/search/song
$urlArray = array(
	'http://m.kugou.com/singer/class',// 获取歌手
	'http://m.kugou.com/plist/index',// 获取歌单
	'http://m.kugou.com/rank/list',// 获取音乐排行榜
	'http://m.kugou.com/rank/info',// 排行版分类歌曲列表
	'http://mobilecdn.kugou.com/api/v3/search/song',// 音乐搜索
	'http://www.kugou.com/yy/index.php',// 播放
	'http://m.kugou.com/singer/list/',// 获取歌手分类下面的歌手列表
	'http://m.kugou.com',// 获取最新音乐
	'http://m.kugou.com/plist/list/',// 获取最新音乐
	'http://m.kugou.com/singer/info/'
);

$opts = array (
	'http' => array (
		'method' => 'GET',
		'timeout'=>10
	)
);

$context = stream_context_create($opts);

if($list == 0){
	$urlArray[$list] = $urlArray[$list]. '&json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}
if($list == 1){
	$urlArray[$list] = $urlArray[$list]. '&json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}
if($list == 2){
	$urlArray[$list] = $urlArray[$list]. '&json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}

if($list == 3){
	$urlArray[$list] = $urlArray[$list] . '?rankid=' . $rankid . 'page=1' . '&json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}
if($list == 4){
	$urlArray[$list] = $urlArray[$list] . '?format=json&keyword=' . $key . '&page=1&pagesize='. $pageSize .'&showtype=1' . '&json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}
if($list == 5){
	$urlArray[$list] = $urlArray[$list] . '?r=play/getdata&hash=' . $hash . '&json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}
if($list == 6){
	$urlArray[$list] = $urlArray[$list] . $id . '?json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}
if($list == 7){
	$urlArray[$list] = $urlArray[$list] . '?json=true' . '&json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}
if($list == 8){
	$urlArray[$list] = $urlArray[$list] . '' . $listId . '?json=true' . '&json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}
if($list == 9){
	$urlArray[$list] = $urlArray[$list] . '' . $test . '?json=true';
	$html = file_get_contents($urlArray[$list], false, $context);
}

echo $html;
?>